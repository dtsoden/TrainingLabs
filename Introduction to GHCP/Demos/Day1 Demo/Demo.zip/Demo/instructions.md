# TMO-DEMO-API: Complete Project Instructions (SQLite Version)

**IMPORTANT: At this stage, you must only generate the following documentation and diagrams:**
- `README.md`: Project summary, quickstart, deployment instructions, and a high-level architecture diagram.
- `PLANNING.md`: Technical design, architecture, dependencies, and detailed system diagrams.
- `TASK.md`: Step-by-step implementation checklist, with flow diagrams for key tasks if needed.
- All diagrams must be valid Mermaid diagrams, encoded as UTF-8 base64, and embedded as image links using the format: `https://mermaid.ink/img/{base64}`.
- Do not build or implement any code yet.

---

## 1. Overview & Complete Setup Instructions
- **Goal:** Create a FastAPI-based REST API for the `customers` table in a local SQLite database.
- **API Endpoints:**
    - `POST /v1/customers` – Add customer (all fields required: `id`, `first_name`, `last_name`, `email`)
    - `GET /v1/customers` – Retrieve all customers
    - `DELETE /v1/customers/{customer_id}` – Delete customer by ID
- **No authentication** (open API)
- **Port:** 8999
- **Deployment:** Local and Docker

### Step-by-Step Setup (Do These in Order)
1. **Python 3.9+ is required.**
2. **Create and activate a virtual environment:**
   ```sh
   python3 -m venv API-ENV
   source API-ENV/bin/activate
   ```
3. **Install all dependencies:**
   ```sh
   pip install -r requirements.txt
   ```
   - If you see `ModuleNotFoundError`, make sure your environment is activated and re-run the install command.
   - Don't forget email-validator as a requirement.
4. **Initialize the SQLite database from the CSV:**
   ```sh
   python init_db.py
   ```
   - This creates `customers.db` with the correct schema and data from `MOCK_DATA.csv`.
   - If you see `sqlite3.OperationalError: no such table`, re-run this step.
5. **Run the API server:**
   ```sh
   uvicorn main:app --reload --port 8999
   ```
   - If you see `Address already in use`, free the port:
     ```sh
     lsof -i :8999
     kill <PID>
     ```
6. **Access the API docs:**
   - Open [http://localhost:8999/docs](http://localhost:8999/docs) in your browser.
7. **Implementation Notes:**
   - The API expects all customer fields (`id`, `first_name`, `last_name`, `email`) to match the columns in `MOCK_DATA.csv`.
   - The Pydantic model in `main.py` must be defined explicitly to match the CSV schema. If you change the CSV, update both the database and the model.
   - The API should never return a generic 500 error. All database and validation errors must return clear, actionable messages.
   - Use `httpie` or `curl` to test endpoints. Always check for 200 responses and correct data.

### Docker (Optional)
- To run in Docker:
  ```sh
  docker build -t TMO-DEMO-API .
  docker run -p 8999:8999 TMO-DEMO-API
  ```

---

*If you follow these steps exactly, you will avoid common setup and runtime issues. No troubleshooting log is needed if these instructions are followed.*

---

## 2. Planning & Reference Docs
- **README.md:** Project summary, quickstart, and deployment instructions.
- **PLANNING.md:** Technical design, architecture, and dependencies.
- **TASK.md:** Step-by-step implementation checklist.
- **MOCK_DATA.csv:** The authoritative data and schema reference. **Column names and types MUST match your code!** Use this CSV to create and populate your SQLite database.

---

## 3. Environment Setup
1. **Python 3.9+** is required.
2. **Create a virtual environment:**
   ```sh
   python -m venv API-ENV
   # Windows:
   API-ENV\Scripts\activate
   # macOS/Linux:
   source API-ENV/bin/activate
   ```
3. **Install dependencies:**
   ```sh
   pip install -r requirements.txt
   ```
4. **Ensure the SQLite database is initialized** using the provided `MOCK_DATA.csv` file. You can use a script to create the schema and import the data.
5. **No additional drivers are required** for SQLite (it is included with Python).

---

## 4. Implementation Notes & Common Pitfalls
- **Column Names:** Your API code must use the exact column names from `MOCK_DATA.csv` (e.g., `customer_id`, not `CustomerID`).
- **customer_id Requirement:** If `customer_id` is NOT auto-incrementing, clients must provide a unique value for each new customer.
- **Database Initialization:** Make sure the SQLite database is created and populated from the CSV before running the API.
- **Error Handling:** The API should never return a generic 500 error. All database and validation errors must return clear, actionable messages.
- **Testing:** Use `httpie` or `curl` to test endpoints. Always check for 200 responses and correct data.

---

## 5. Running the API
- **Locally:**
  ```sh
  uvicorn main:app --reload --port 8999
  ```
- **Docker:**
- Use a base Docker image that supports this application and includes SQLite (Python images do by default)
  ```sh
  docker build -t TMO-DEMO-API .
  docker run -p 8999:8999 TMO-DEMO-API
  ```
- **Swagger UI:** Visit [http://localhost:8999/docs](http://localhost:8999/docs)

---

## 6. Troubleshooting Checklist
- [ ] Did you match all code field names to the schema in `MOCK_DATA.csv`?
- [ ] Is your environment activated and all dependencies installed?
- [ ] Is the SQLite database initialized and populated from the CSV?
- [ ] Do all endpoints return 200 for valid requests (and clear errors otherwise)?

---

## 7. Additional References
- For design and requirements, see `PLANNING.md` and `TASK.md`.
- For sample data and schema, see `MOCK_DATA.csv`.

---

## 8. Streamlined Setup Instructions (2025-06-08)

Follow these steps to build and run the TMO-DEMO-API project successfully the first time:

### 1. Environment Setup
- Ensure you have **Python 3.9+** installed.
- Create and activate a virtual environment:
  ```sh
  python3 -m venv API-ENV
  source API-ENV/bin/activate
  ```
- Install all dependencies:
  ```sh
  pip install -r requirements.txt
  ```

### 2. Database Initialization
- Before running the API, initialize the SQLite database from the provided CSV:
  ```sh
  python init_db.py
  ```
- This creates `customers.db` with the correct schema and data.

### 3. Running the API
- Start the FastAPI server:
  ```sh
  uvicorn main:app --reload --port 8999
  ```
- If you see `Address already in use`, free the port:
  ```sh
  lsof -i :8999
  kill <PID>
  ```
- Access the API docs at: [http://localhost:8999/docs](http://localhost:8999/docs)

### 4. Implementation Notes
- The API expects all customer fields (`id`, `first_name`, `last_name`, `email`) to match the columns in `MOCK_DATA.csv`.
- The Pydantic model in `main.py` must be defined explicitly to match the CSV schema.
- If you change the CSV schema, update both the database and the model.

### 5. Docker (Optional)
- To run in Docker:
  ```sh
  docker build -t TMO-DEMO-API .
  docker run -p 8999:8999 TMO-DEMO-API
  ```

---

*Follow these steps exactly to avoid common setup and runtime issues. No troubleshooting log is needed if these instructions are followed.*

---

**IMPORTANT: Mermaid Diagrams**
- Always use simple, single-line node labels (no special characters or parentheses).
- Use newlines (not semicolons) to separate lines in Mermaid code.
- Validate your Mermaid code at https://mermaid.live before encoding.
- Encode only valid, working diagrams as UTF-8 base64 (no whitespace, no code block markers).
- Always open the image link (https://mermaid.ink/img/{base64}) to confirm it renders as expected.
- If the image does not render, fix the code and re-encode. Never embed broken or unvalidated diagrams.

**Minimal working example:**

Mermaid code (copy this into https://mermaid.live to check):

```
flowchart TD
    A[Client]
    A -- POST/GET/DELETE --> B[FastAPI]
    B -- SQL(CRUD) --> C[SQLite DB]
```

Encoded base64 (no whitespace, no code block markers):
```
Zmxvd2NoYXJ0IFRECiAgICBBW0NsaWVudF0KICAgIEEgLS0gUE9TVC9HRVQvREVMRVRFIC0tPiBCW0Zhc3RBUFJdCiAgICBCIC0tIFNRTCgkQ1JVRCRdIC0tPiBDW1NRTGl0ZSBEQl0K
```

Image link (open to validate):
```
https://mermaid.ink/img/Zmxvd2NoYXJ0IFRECiAgICBBW0NsaWVudF0KICAgIEEgLS0gUE9TVC9HRVQvREVMRVRFIC0tPiBCW0Zhc3RBUFJdCiAgICBCIC0tIFNRTCgkQ1JVRCRdIC0tPiBDW1NRTGl0ZSBEQl0K
```

*Validate this image by opening the link above. Only embed if it renders correctly.*

---

**If you follow these instructions, you will avoid the most common issues and confusion. If you encounter a new problem, update this file to help the next developer!**
